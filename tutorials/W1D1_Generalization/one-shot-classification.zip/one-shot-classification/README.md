Classification runs taken directly from the Omniglot repository:
https://github.com/brendenlake/omniglot/tree/master/python/one-shot-classification